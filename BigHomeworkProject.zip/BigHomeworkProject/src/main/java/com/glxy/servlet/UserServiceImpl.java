package com.glxy.servlet;

import com.glxy.bean.User;
import com.glxy.mapper.UserMapper;
import com.glxy.util.MybatisUtils;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

public class UserServiceImpl implements UserService {
    @Override
    public boolean login(User user) {
        SqlSessionFactory sqlSessionFactory = MybatisUtils.getSqlSessionFactory();
        SqlSession sqlSession = sqlSessionFactory.openSession(true);
        UserMapper mapper = sqlSession.getMapper(UserMapper.class);
        User u = mapper.selectByUserAndPassword(user);
        return u != null;
    }

    @Override
    public User selectAll(User user) {
        SqlSessionFactory sqlSessionFactory = MybatisUtils.getSqlSessionFactory();
        SqlSession sqlSession = sqlSessionFactory.openSession(true);
        UserMapper mapper = sqlSession.getMapper(UserMapper.class);
        User user1 = mapper.selectAll(user);
        return  user1;
    }

}
