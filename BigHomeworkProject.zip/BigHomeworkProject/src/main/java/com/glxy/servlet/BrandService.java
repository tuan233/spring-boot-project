package com.glxy.servlet;

import com.glxy.bean.Brand;

import java.util.ArrayList;

public interface BrandService {
    ArrayList<Brand> selectAllBrand();

    void add(Brand brand);
}
