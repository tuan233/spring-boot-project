package com.glxy.servlet;

import com.glxy.bean.Book;

import java.util.ArrayList;

public interface BookService {

    ArrayList<Book> selectAll();

    ArrayList<Book> selectCondition(String queryName);

    void addBook(Book book);

    void delete(Integer id);

    int update(Book book);

}
