package com.glxy.servlet;

import com.glxy.bean.User;

public interface UserService {

    boolean login(User user);

    User selectAll(User user);

}
