package com.glxy.mapper;

import com.glxy.bean.Brand;

import java.util.ArrayList;

public interface BrandMapper {

    ArrayList<Brand> selectAll();

    void add(Brand brand);

}
