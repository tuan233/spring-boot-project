package com.glxy.mapper;

import com.glxy.bean.Book;

import java.util.ArrayList;

public interface BookMapper {

    ArrayList<Book> selectAll();

    ArrayList<Book> selectCondition(String queryName);

    void addBook(Book book);

    int deleteByID(Integer id);

    int update(Book book);
}
