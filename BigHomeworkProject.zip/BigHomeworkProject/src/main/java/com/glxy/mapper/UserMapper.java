package com.glxy.mapper;

import com.glxy.bean.User;
import org.apache.ibatis.annotations.Select;

public interface UserMapper {

    User selectByUserAndPassword(User user);

    User selectAll(User user);

}
