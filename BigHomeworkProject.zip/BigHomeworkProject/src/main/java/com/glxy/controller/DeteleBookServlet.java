package com.glxy.controller;

import com.alibaba.fastjson.JSON;
import com.glxy.servlet.BookService;
import com.glxy.servlet.BookServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/deleteBookServlet")
public class DeteleBookServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        System.out.println("服务器---删除");
        request.setCharacterEncoding("utf8");
        String id = request.getParameter("id");
        System.out.println(id);
        Integer id1 = Integer.valueOf(id);
        BookService service = new BookServiceImpl();
        service.delete(id1);
        response.setContentType("text/html");
        response.setCharacterEncoding("utf8");
        response.getWriter().println("删除成功");
        response.sendRedirect("/BigHomeworkProject/html/library.html");
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
}
