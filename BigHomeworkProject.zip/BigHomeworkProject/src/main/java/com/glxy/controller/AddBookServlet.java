package com.glxy.controller;

import com.alibaba.fastjson.JSON;
import com.glxy.bean.Book;
import com.glxy.servlet.BookService;
import com.glxy.servlet.BookServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/addBookServlet")
public class AddBookServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf8");
        final String jsonStr = request.getReader().readLine();
        final Book book = JSON.parseObject(jsonStr, Book.class);
        BookService service = new BookServiceImpl();
        service.addBook(book);
        response.getWriter().print("success");
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
}
