package com.glxy.controller;

import com.alibaba.fastjson.JSON;
import com.glxy.bean.Book;
import com.glxy.servlet.BookService;
import com.glxy.servlet.BookServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;

@WebServlet("/SelectBookServlet")
public class SelectBookServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        BookService service = new BookServiceImpl();
        ArrayList<Book> books = service.selectAll();//查询全部
//        System.out.println(books);
        String bookJson = JSON.toJSONString(books);

        response.setContentType("text/html");
        response.setCharacterEncoding("utf8");
        response.getWriter().print(bookJson);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
}
