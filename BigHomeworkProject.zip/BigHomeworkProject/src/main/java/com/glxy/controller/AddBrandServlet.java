package com.glxy.controller;

import com.alibaba.fastjson.JSON;
import com.glxy.bean.Brand;
import com.glxy.servlet.BrandServiceImpl;
import com.glxy.servlet.BrandService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/addBrandServlet")
public class AddBrandServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf8");
        String jsonStr = request.getReader().readLine();
        Brand brand = JSON.parseObject(jsonStr, Brand.class);

        BrandService servlet = new BrandServiceImpl();
        servlet.add(brand);
        response.getWriter().print("success");
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
}
